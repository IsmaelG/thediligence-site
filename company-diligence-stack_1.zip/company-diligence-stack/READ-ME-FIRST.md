# Company diligence pack

Everything you need to walk into a meeting, a board seat or a first call knowing more about a company than the person across the table.

```
/duediligence  ->  /companypeople  ->  /targetpeople        (/interviewlog feeds the evidence in, /onbrand restyles the result)
```

## What is in this pack

**`/duediligence`** — Give it a company name, get back a short report you could take into a meeting: the money (or the best signals available when there are no accounts), the strategy, who owns the company, an honest list of strengths and weaknesses, and an org chart with the person who really runs digital.

**`/interviewlog`** — Turns messy call notes, voice memos and transcripts into a tidy list of sources — one entry per conversation, with clean quotes you can cite in a report.

**`/companypeople`** — Who really decides, mapped out: an org chart, a page on each person — what they have actually done, who backs them, what they say in public — plus a likely work email and a short opening message.

**`/targetpeople`** — How to get in front of named people: every realistic route ranked by the chance it works, with the exact message written for each step and when to send it.

**`/onbrand`** — Takes a finished report and puts it in another company's colours and fonts, read from their own website, so it lands looking like it came from inside their offices.

## What is behind each question

### Is it a good company?  `/duediligence`
- **The money** — revenue, margins, cash, debt. From filed accounts, or from proxy signals where
  there are none.
- **The people** — who runs it, who they hired, who left and when.
- **The key events** — funding, acquisitions, big customer wins and losses, restructurings, sites
  opened or closed.
- **Who owns it** — who controls the company, and what they want from it.
- **Where it stands** — who it competes with, where it wins, and where it is losing.

### Will the product keep growing?  `/productdd` — eight checks, each scored out of five
1. **What problem does it solve?** Ask five customers, without prompting. If they describe the
   value the same way, the positioning is real. Then: does the person who *pays* feel the pain, or
   only the person who uses it? If only the user, sales drag on for months.
2. **Who is the right customer?** One group often loves the product while the rest leave. The
   average hides it. The most common finding.
3. **Do customers stay?** A leaky bucket. If the drop-off levels out there is a loyal core. If it
   keeps falling, sales are refilling a bucket with no bottom. Built from raw customer data, not
   management's chart.
4. **How big is the market, really?** Count real buyers from the bottom up. Ignore "the market is
   EUR 7bn, we'll take 1%". A few big accounts, or thousands of small ones? Different rivals,
   different prices.
5. **What stops a competitor copying it?** Features get copied. The cost of switching, data that
   improves with use, and access to customers do not. And could the customer build it in-house?
6. **Does the price grow with the value?** If a customer gets three times more value and pays the
   same, income from existing customers is capped. Sales effort will not fix it.
7. **Does the sales approach fit the price?** An 80k contract needs a salesperson. A 500 product
   cannot afford one. Does it sell without the founder in the room?
8. **Can the team deliver the plan?** Shipping pace, whether they talk to users, how much old code
   is in the way. Tells you if the plan after investment is realistic, or just nice on paper.

## How to install

### Option A — the Claude app (claude.ai, desktop or web)
Tools are added one at a time, each as its own small zip.

1. Open the folder `claude-app-upload/` in this pack. It already holds one zip per tool.
2. In Claude, open **Settings -> Skills** (some accounts say **Customize -> Skills**) and choose
   **Upload skill**.
3. Add each zip. Do all of them — the tools are built to work together.

### Option B — on your own computer (Claude Code or Cowork)
1. Copy the folders inside `skills/` into your personal skills folder:
   `~/.claude/skills/`
   so you end up with `~/.claude/skills/duediligence/SKILL.md`.
2. Restart Claude. Type `/` and they appear in the list.
   (For one project only, use `.claude/skills/` inside that project.)

### Check it worked
Ask Claude: **"which diligence skills do you have?"** — it should list them by name.
Then try one: **`/duediligence Acme Corp`**.

## What the scripts need
Python 3 with `python-docx` for the Word reports, `pandas` for `/cohortlab`, and — only if you
want the visual check in `/onbrand` — LibreOffice (`soffice`) and `pdftoppm`. Claude installs
what is missing when it is allowed to.

## The rules these tools follow
- **Every number carries a mark** — `[A]` official accounts, invoices, or figures worked out from
  raw data · `[B]` what someone told us · `[C]` an estimate or a single source. Mixing marks in
  one sentence counts as a mistake.
- **Every claim points to a source** (`S-01` a document, `I-01` an interview, `P-01` something
  published) that must appear on the source list. A check refuses to print a report where one
  does not.
- **Research first, write last.** Roughly 70% finding things out, 20% building the argument,
  10% making the document.
- **What is missing is part of the job.** Anything that could not be checked becomes a line in
  the appendix: what is needed, why, who has it, how to get it, how urgent.

## Notes
- `/interviewlog` and `/onbrand` are in both packs on purpose. Install both and they simply
  replace each other with the same files.
- The worked examples inside are invented, not real clients.
- Nothing is hard-wired to one folder. The tools save to the Claude app's output folder when there
  is one, otherwise to a folder you name once, otherwise to wherever you are working.
